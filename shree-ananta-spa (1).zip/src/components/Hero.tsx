import { motion } from 'motion/react';
import { ArrowRight, MessageCircle } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative h-screen min-h-[600px] w-full overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src="https://drive.google.com/thumbnail?id=1K_PLGxFRWELTlmxHmpZahuDn7BnemSiE&sz=w1920" 
          alt="Luxury Spa Background" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
        <div className="absolute inset-0 bg-gold-900/20 mix-blend-overlay" />
      </div>

      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="space-y-6 max-w-4xl"
        >
          <span className="inline-block py-1 px-3 border border-gold-400/50 rounded-full text-gold-300 text-sm tracking-[0.2em] uppercase bg-black/30 backdrop-blur-sm">
            Premium Wellness in Udaipur
          </span>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-tight drop-shadow-lg">
            <span className="block text-gold-400 mb-2">Shree Ananta Spa</span>
            Authentic Thai & <br/>
            <span className="text-white italic">Organic Wellness</span> Rituals
          </h1>
          
          <p className="text-lg md:text-xl text-gray-200 max-w-2xl mx-auto font-light leading-relaxed">
            Experience healing, relaxation and premium Thai wellness at Shree Ananta Spa.
            A sanctuary designed for your inner peace.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <a 
              href="https://wa.me/919588812154"
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-gold-500 hover:bg-gold-400 text-white px-8 py-4 rounded-full text-lg font-medium transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Book Appointment
            </a>
            <a 
              href="#therapies"
              className="group bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white px-8 py-4 rounded-full text-lg font-medium transition-all flex items-center justify-center gap-2"
            >
              View Therapies
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </motion.div>
      </div>

      {/* Decorative bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-spa-bg to-transparent" />
    </section>
  );
}
